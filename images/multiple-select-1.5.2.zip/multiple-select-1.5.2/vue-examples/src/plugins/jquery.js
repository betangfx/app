import jQuery from 'jquery'
window.$ = window.jQuery = jQuery
