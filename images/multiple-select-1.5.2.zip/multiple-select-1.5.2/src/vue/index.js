import MultipleSelect from './MultipleSelect.vue'

export default MultipleSelect
